package com.shinhan.day06.CH7;

public class A {
	public void method1() {
		System.out.println("A-method1()");
	}
}
