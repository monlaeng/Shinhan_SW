package com.shinhan.day06.CH7;

public class Child extends Parent{
	public int studentsNo;
	
	public Child(String name, int studentsNo) {
		super(name);
		this.studentsNo = studentsNo;
	}
}
