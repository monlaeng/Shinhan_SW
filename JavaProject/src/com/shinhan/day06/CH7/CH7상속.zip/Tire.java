package com.shinhan.day06.CH7;

public class Tire {
	public void run() {
		System.out.println("일반 타이어가 굴러갑니다.");
	}
}
