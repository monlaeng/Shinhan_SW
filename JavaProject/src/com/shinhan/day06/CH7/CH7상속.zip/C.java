package com.shinhan.day06.CH7;

public class C extends A {
	public void method1() {
		System.out.println("C-method1()");
	}
	public void method2() {
		System.out.println("C-method2()");
	}
}
