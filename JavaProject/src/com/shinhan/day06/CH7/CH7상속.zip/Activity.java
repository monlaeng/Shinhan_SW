package com.shinhan.day06.CH7;

public class Activity {
	public void onCreate() {
		System.out.println("기본적인 실행 내용");
	}
}
