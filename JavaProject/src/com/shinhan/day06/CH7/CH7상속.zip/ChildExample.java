package com.shinhan.day06.CH7;

public class ChildExample {
	public static void main(String[] args) {
		Child2 child = new Child2();
	}
}
